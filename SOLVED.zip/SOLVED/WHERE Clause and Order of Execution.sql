use sqltask;

/*List Consumer_IDs and the count of restaurants they've rated, but only for consumers who are 'Students'. 
Show only students who have rated more than 2 restaurants.*/

select distinct rgs.consumer_id,count(rgs.Restaurant_ID) as rated_count 
				from ratings rgs join consumers c on rgs.Consumer_ID=c.Consumer_ID
                where c.occupation="student" group by rgs.consumer_id  having rated_count>2 ;


/*We want to categorize consumers by an 'Engagement_Score' which is their Age divided by 10 (integer division). List the Consumer_ID, Age, 
and this calculated Engagement_Score, but only for consumers whose Engagement_Score would be exactly 2 and who use 'Public' transportation.*/

select Consumer_ID,age,age/10 as Engagement_Score from Consumers where (age/10)=2 and Transportation_Method="public";


/*For each restaurant, calculate its average Overall_Rating. Then, list the restaurant Name, City, and its calculated average Overall_Rating, 
but only for restaurants located in 'Cuernavaca' AND whose calculated average Overall_Rating is greater than 1.0.*/

select r.Name,r.City,avg(rgs.Overall_Rating) as avg_Overall_Rating 
		from restaurants r 
        join ratings rgs on r.Restaurant_ID=rgs.Restaurant_ID
        where r.city="Cuernavaca"
        group by r.name,r.city
        having avg_Overall_Rating>1;


/*Find consumers (Consumer_ID, Age) who are 'Married' and whose Food_Rating for any restaurant is equal to their Service_Rating for that same restaurant, 
but only consider ratings where the Overall_Rating was 2.*/

select distinct c.Consumer_ID,c.Age from consumers c 
						   join ratings rgs on c.Consumer_ID=rgs.Consumer_ID
                           where rgs.Overall_Rating=rgs.Service_Rating and rgs.Overall_Rating=2 and Marital_Status="Married";


/*List Consumer_ID, Age, and the Name of any restaurant they rated, but only for consumers who are 'Employed' 
and have given a Food_Rating of 0 to at least one restaurant located in 'Ciudad Victoria'.*/

select c.Consumer_ID,c.Age,r.name from consumers c 
							join ratings rgs on c.Consumer_ID=rgs.Consumer_ID
                            join restaurants r on r.restaurant_id=rgs.restaurant_id
                            where c.occupation="employed" and rgs.Food_Rating=0 and r.city="Ciudad Victoria";
