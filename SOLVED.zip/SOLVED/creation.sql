create database SQLTASK;

use sqltask;

create table consumers(Consumer_ID varchar(10) primary key ,
						City varchar(20),
                        State varchar(20),
                        Country varchar(20),
                        Latitude int,
                        Longitude int,
                        Smoker varchar(3),
                        Drink_Level varchar(20),
                        Transportation_Method varchar(20),
                        Marital_Status varchar(10),
                        Children varchar(20),
                        Age int,
                        Occupation varchar(20),
                        Budget varchar(10) check (Budget in ('low','medium','high'))
                        );

create table consumer_preferences(Consumer_ID varchar(10) primary key,
								  Preferred_Cuisine varchar(20),
                                  FOREIGN KEY (Consumer_ID) REFERENCES consumers(Consumer_ID)
                                  );
                                  
create table restaurants (Restaurant_ID int(10) primary key,
						  Name varchar(30),
                          City varchar(20),
                          State varchar(20),
                          Country varchar(20),
                          Zip_Code varchar(5),
                          Latitude int,
                          Longitude int,
                          Alcohol_Service varchar(15) check(Alcohol_Service in ("Full Bar","None","Wine & Beer")),
                          Smoking_Allowed varchar(15) check(smoking_allowed in ("Smoking Section","Yes","Bar Only","No")),
                          Price varchar(10) check(price in ('Low','Medium','High')),
                          Franchise varchar(3) check (franchise in('Yes','No')),
                          Area varchar(10) check (area in ('open','closed')),
                          Parking varchar(10) check (parking in ('Yes','None','Public,Valet'))
                          );
                          
create table restaurant_cuisines(Restaurant_ID int,
								 Cuisine varchar(100),
                                 foreign key (restaurant_id) references restaurants(restaurant_id)
                                 );

create table ratings(Consumer_ID varchar(10),
					 Restaurant_ID int,
                     Overall_Rating tinyint,
                     Food_Rating tinyint,
                     Service_Rating tinyint,
                     primary key (Consumer_ID,Restaurant_ID),
                     foreign key (consumer_id) references consumers(consumer_id),
                     foreign key (restaurant_id) references restaurants(restaurant_id)
                     );
                     
CREATE TABLE data_dictionary (Table_Name VARCHAR(20),
							  Field_Name VARCHAR(30),
                              Description TEXT
                              );
                              
select * from data_dictionary;