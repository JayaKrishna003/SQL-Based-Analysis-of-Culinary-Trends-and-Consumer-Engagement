use sqltask;

-- Q1)
/* Using a CTE, find all consumers who live in 'San Luis Potosi'. 
Then, list their Consumer_ID, Age, and the Name of any Mexican restaurant they have rated with an Overall_Rating of 2.*/
with cts as (
			select consumer_id,age 
			from consumers 
			where city = "San Luis Potosi"
            )
			select 
				cts.consumer_id,
                cts.age,
                r.name 
				from 
					cts 
				join ratings rgs on cts.consumer_id=rgs.consumer_id
				join restaurants r on rgs.Restaurant_ID=r.Restaurant_ID
				join restaurant_cuisines rc on r.Restaurant_ID=rc.Restaurant_ID
				where rgs.overall_rating = 2 and rc.cuisine ="mexican";

-- Q2)
/*
For each Occupation, find the average age of consumers. Only consider consumers who have made at least one rating. 
(Use a derived table to get consumers who have rated).
*/

select c.Occupation,avg(c.age) as avg_age 
		from (select consumer_id from ratings) as rtg 
        JOIN consumers c ON rtg.Consumer_ID = c.Consumer_ID 
        group by Occupation;


-- Q3)
/*Using a CTE to get all ratings for restaurants in 'Cuernavaca', rank these ratings within each restaurant based on Overall_Rating (highest first). 
Display Restaurant_ID, Consumer_ID, Overall_Rating, and the RatingRank.
For each rating, show the Consumer_ID, Restaurant_ID, Overall_Rating, and also display 
the average Overall_Rating given by that specific consumer across all their ratings.*/

select * from ratings;
select * from consumers;
select * from restaurants;

with Cuernavaca_ratings as
	(
    select r.Restaurant_ID,rts.Consumer_ID, rts.Overall_Rating 
    from ratings rts
    join restaurants r on rts.Restaurant_ID=r.Restaurant_ID
    where r.City="Cuernavaca"
    ),
    ranked_ratings as
    (
    select cr.Restaurant_ID,cr.consumer_id,cr.overall_rating,
    rank()
    over(partition by cr.Restaurant_ID order by overall_rating desc) as rating_rank 
    from Cuernavaca_ratings cr
    ),
	consumer_avg_rating AS (
		SELECT 
			Consumer_ID,
			AVG(Overall_Rating) AS Avg_Overall_Rating
		FROM 
			ratings
		GROUP BY 
			Consumer_ID
	)
	SELECT 
		rr.Restaurant_ID,
		rr.Consumer_ID,
		rr.Overall_Rating,
		rr.Rating_Rank,
		car.Avg_Overall_Rating
	FROM 
		ranked_ratings rr
	JOIN 
		consumer_avg_rating car ON rr.Consumer_ID = car.Consumer_ID;

-- Q4)

/*Using a CTE, identify students who have a 'Low' budget. Then, for each of these students, 
list their top 3 most preferred cuisines based on the order they appear in the Consumer_Preferences table 
(assuming no explicit preference order, use Consumer_ID, Preferred_Cuisine to define order for ROW_NUMBER).*/
select * from ratings;
select * from consumers;
select * from restaurant_cuisines;
select * from consumer_preferences;

with lowbudget as
	(select 
		c.Consumer_ID 
        from consumers c
        where c.Budget="Low" and c.occupation="student"
    ),
ranked as
	(select 
		cp.Consumer_ID,cp.Preferred_Cuisine,
        row_number() over(partition by cp.consumer_id order by cp.Preferred_Cuisine)
        as rn
	from 
		consumer_preferences cp
		join lowbudget lb on cp.Consumer_ID=lb.Consumer_ID
    )
    select 
		consumer_id,Preferred_Cuisine
	from ranked
    where rn<=3;

-- Q5)    
/*Consider all ratings made by 'Consumer_ID' = 'U1008'. For each rating, show the Restaurant_ID, Overall_Rating, 
and the Overall_Rating of the next restaurant they rated (if any), ordered by Restaurant_ID 
(as a proxy for time if rating time isn't available). Use a derived table to filter for the consumer's ratings first.*/

select  Restaurant_ID,
		overall_rating,
        lead(overall_rating) over(order by Restaurant_ID) as next_overall_rating
		from 
        (select Restaurant_ID,
				overall_rating
		 from ratings
         where Consumer_ID = 'U1008'
		) as consumer_ratings;

-- Q6)
/*Create a VIEW named HighlyRatedMexicanRestaurants that shows the Restaurant_ID, Name, and City of all 
Mexican restaurants that have an average Overall_Rating greater than 1.5.*/

create view 
			HighlyRatedMexicanRestaurants as 
			select r.Restaurant_ID, r.Name, r.City 
            from restaurants r
            join restaurant_cuisines rc on r.Restaurant_ID=rc.Restaurant_ID
            join ratings rts on r.Restaurant_ID=rts.Restaurant_ID
            where rc.Cuisine='Mexican'
            group by r.Restaurant_ID, r.Name, r.City
            having avg(rts.Overall_Rating)>1.5;

select * from HighlyRatedMexicanRestaurants;

-- Q7)
/*First, ensure the HighlyRatedMexicanRestaurants view from Q7 exists. Then, 
using a CTE to find consumers who prefer 'Mexican' cuisine, list those consumers (Consumer_ID)
 who have not rated any restaurant listed in the HighlyRatedMexicanRestaurants view.*/

select * from consumer_preferences;
with cts as(
			select consumer_id
            from consumer_preferences
            where Preferred_Cuisine='Mexican'
            ),
	rhr as (
            select distinct consumer_id 
            from ratings 
            where Restaurant_ID 
            in (select restaurant_id from HighlyRatedMexicanRestaurants)
            )
	select cts.consumer_id 
    from cts
    left join rhr on cts.consumer_id=rhr.consumer_id
    where rhr.consumer_id is null;

-- Q8)
/*Create a stored procedure GetRestaurantRatingsAboveThreshold that accepts a Restaurant_ID and a minimum Overall_Rating as input. 
It should return the Consumer_ID, Overall_Rating, Food_Rating, and Service_Rating for that restaurant where the Overall_Rating meets or exceeds the threshold.*/

delimiter $$
create procedure 
				GetRestaurantRatingsAboveThreshold(in input_Restaurant_ID int,in min_rating tinyint)
                begin
                select 
					Consumer_ID, Overall_Rating, Food_Rating,Service_Rating
                    from ratings
                    where Restaurant_ID=input_Restaurant_ID
						and Overall_Rating>=min_rating;
                end$$
delimiter ;

-- Q9)
/*Identify the top 2 highest-rated (by Overall_Rating) restaurants for each cuisine type. 
If there are ties in rating, include all tied restaurants. Display Cuisine, Restaurant_Name, City, and Overall_Rating.
*/

with avgratings as
(
	select rts.restaurant_id,
			rc.cuisine as cuisine,
			r.name as restaurant_name,
			r.city as city,
			avg(rts.overall_rating) as average_rating
		from 
			ratings rts
		join restaurants r on rts.Restaurant_ID=r.Restaurant_ID
		join restaurant_cuisines rc on rts.Restaurant_ID=rc.Restaurant_ID
		group by 
			rts.restaurant_id,
			rc.cuisine,
			r.name,
			r.city
),
ranked_cuisines as 
(
	SELECT 
			Cuisine,
			Restaurant_Name,
			City,
			Average_Rating,
			RANK() OVER (PARTITION BY Cuisine ORDER BY Average_Rating DESC) AS rating_rank
		FROM 
			AvgRatings
)
SELECT 
    Cuisine,
    Restaurant_Name,
    City,
    Average_Rating AS Overall_Rating
FROM 
    ranked_cuisines
WHERE 
    rating_rank <= 2;
