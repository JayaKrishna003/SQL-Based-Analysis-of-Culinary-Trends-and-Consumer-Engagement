use sqltask;

-- Joins


-- List the names and cities of all restaurants that have an Overall_Rating of 2 (Highly Satisfactory) from at least one consumer.
/*(select name, city from restaurants where Restaurant_ID in (select restaurant_id from ratings where Overall_Rating>1);)*/

select distinct rs.name,rs.city from restaurants rs inner join ratings rt on rs.restaurant_id=rs.restaurant_id where rt.overall_rating>1;


-- Find the Consumer_ID and Age of consumers who have rated restaurants located in 'San Luis Potosi'.
select distinct c.Consumer_ID,
	   c.age from consumers c
       inner join ratings r on r.Consumer_ID=c.Consumer_ID 
       inner join restaurants re on r.Restaurant_ID = re.Restaurant_ID where re.City = 'San Luis Potosi';


-- List the names of restaurants that serve 'Mexican' cuisine and have been rated by consumer 'U1001'.

select distinct r.name as restaurant_name,rc.cuisine from 
			restaurants r 
            inner join restaurant_cuisines rc on r.Restaurant_ID=rc.Restaurant_ID
            inner join ratings rt on r.Restaurant_ID=rt.Restaurant_ID
            where rt.consumer_id='u1001'
            ;


-- Find all details of consumers who prefer 'American' cuisine AND have a 'Medium' budget.
select * from consumers c 
			  inner join consumer_preferences cp on c.Consumer_ID=cp.Consumer_ID where cp.Preferred_Cuisine="american" and c.budget="medium";



-- List restaurants (Name, City) that have received a Food_Rating lower than the average Food_Rating across all rated restaurants.
select distinct r.name,r.city from restaurants r 
				right join ratings rgs on r.Restaurant_ID=rgs.Restaurant_ID where rgs.overall_rating<1;

-- Find consumers (Consumer_ID, Age, Occupation) who have rated at least one restaurant but have NOT rated any restaurant that serves 'Italian' cuisine.
select distinct c.consumer_id,c.age,c.occupation 
		from consumers c 
		join ratings rgs on c.consumer_id=rgs.consumer_id
        where c.consumer_id not in
        (select rgs.consumer_id from ratings rgs join restaurant_cuisines rcs on rgs.restaurant_id=rcs.restaurant_id WHERE rcs.Cuisine = 'Italian')
		;

-- List restaurants (Name) that have received ratings from consumers older than 30.
select distinct r.name from ratings rgs
		join restaurants r on r.Restaurant_ID=rgs.Restaurant_ID
        join consumers c on rgs.Consumer_ID=c.Consumer_ID
        where c.age>30;

-- Find the Consumer_ID and Occupation of consumers whose preferred cuisine is 'Mexican' and who have given an Overall_Rating of 0 to at least one restaurant (any restaurant).
select distinct c.Consumer_ID,c.occupation from consumers c
		inner join consumer_preferences cp on c.Consumer_ID=cp.Consumer_ID
        inner join ratings rgs on c.consumer_id=rgs.consumer_id
        where rgs.overall_rating=0;

-- List the names and cities of restaurants that serve 'Pizzeria' cuisine and are located in a city where at least one 'Student' consumer lives.
select r.name,r.city from restaurants r 
		join restaurant_cuisines rcs on r.restaurant_id=rcs.restaurant_id
        join consumers c on r.city=c.city
        where rcs.cuisine="Pizzeria" and c.occupation="student";

-- Find consumers (Consumer_ID, Age) who are 'Social Drinkers' and have rated a restaurant that has 'No' parking.

select c.consumer_id,c.age from consumers c 
			join ratings rgs on c.consumer_id=rgs.consumer_id
            join restaurants r on r.restaurant_id=rgs.restaurant_id
            where c.Drink_Level='Social Drinkers' and r.parking="No";